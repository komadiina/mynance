package ocjena;

/*
 Napraviti klasu Ocjena i metod getOcjena(Integer lab, Integer
ispit)
� 0 = lab = 25
� 0 = ispit = 75
 Metod vraca String ocjenu:
� A za 91-100
� B za 81-90
� C za 71-80
� D za 61-70
� E za 51-60
� F za <51
� ERR za sve neispravne ulaze
 Napraviti jedinicne testove i ispitati pokrivenost
*/

public class Ocjena {
	
	public Ocjena() {}
	
	public String getOcjena(Integer lab, Integer ispit) {
		
		int bodovi = lab + ispit;
		
		if(lab < 0 || lab > 25 || ispit < 0 || ispit > 75) {
			return "ERR";
		} else if(bodovi >= 91) {
			return "A";
		} else if(bodovi >= 81) {
			return "B";
		} else if(bodovi >= 71) {
			return "C";
		} else if(bodovi >= 61) {
			return "D";
		} else if(bodovi >= 51) {
			return "E";
		} else {
			return "F";
		}
	}	
}
