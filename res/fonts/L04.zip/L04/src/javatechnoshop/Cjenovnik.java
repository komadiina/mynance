package javatechnoshop;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javatechnoshop.proizvodi.Proizvod;

public class Cjenovnik {

    private List<Proizvod> proizvodi = new ArrayList<Proizvod>();

    public Cjenovnik() {

    }

    public List<Proizvod> pretraga(String naziv) {
    	return proizvodi.stream()                
                 .filter(proizvod -> proizvod.getNaziv().contains(naziv))     
                 .collect(Collectors.toList());
    }


    public List<Proizvod> pretragaPoSifri(String sifra) {
    	return proizvodi.stream()                
                 .filter(proizvod -> proizvod.getSifra().contains(sifra))     
                 .collect(Collectors.toList());
    }
    
    public Boolean dodajProizvod(Proizvod p) {
    	if(p != null)
    	{
    	if(getProizvodSaSifrom(p.getSifra()) == null)
    		{
    			this.proizvodi.add(p);
    			return true;
    		}
    	}
    	return false;
    }
    
    public Proizvod getProizvodSaSifrom(String sifra) {        
        for (Proizvod p : proizvodi) {
            if (p.getSifra().equals(sifra)) {
                return p;
            }
        }
        return null;
    }

}
