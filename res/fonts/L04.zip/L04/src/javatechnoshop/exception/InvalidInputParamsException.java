package javatechnoshop.exception;

public class InvalidInputParamsException extends Exception{

	public InvalidInputParamsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidInputParamsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
