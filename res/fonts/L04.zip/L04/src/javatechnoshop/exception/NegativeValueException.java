package javatechnoshop.exception;

public class NegativeValueException extends Exception{

	public NegativeValueException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NegativeValueException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
