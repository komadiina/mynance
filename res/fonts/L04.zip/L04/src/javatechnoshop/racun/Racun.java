package javatechnoshop.racun;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javatechnoshop.exception.InvalidInputParamsException;
import javatechnoshop.exception.NegativeValueException;
import javatechnoshop.proizvodi.Proizvod;

public class Racun {

	private List<Stavka> stavke = new ArrayList<Stavka>();
	public Date datumKupovine;
	private Double cijena;

	public Racun() {

	}

	public Optional<Stavka> getStavkaSaSifromProizvoda(String sifra) {
		return stavke.stream().filter(s -> s.getProizvod().getSifra().equals(sifra)).findAny();
	}

	public void azurirajStavku(Proizvod p, Integer kolicina) throws NegativeValueException, InvalidInputParamsException {
		if (p != null && kolicina!= null) {
			Optional<Stavka> stavkaOpt = getStavkaSaSifromProizvoda(p.getSifra());
			if (stavkaOpt.isPresent()) {
				Stavka stavka = stavkaOpt.get();
				Integer razlika = stavka.getKolicina() + kolicina;
				if(razlika == 0)
					stavke.remove(stavka);
				else if (razlika < 0)
					throw new NegativeValueException("Stavka na racunu bi otisla u minus!");
				else
					stavka.setKolicina(stavka.getKolicina() + kolicina);
			} 
			else
				stavke.add(new Stavka(stavke.size()+1, p, kolicina));
		}
		else
			throw new InvalidInputParamsException("Parametri su neispravni");
	}

	public void ukloniStavku(Proizvod p) {
		stavke.removeIf(s -> s.getProizvod().equals(p));
	}

	public void pregledStavki() {
		System.out.println("Naruceni proizvodi:");
		System.out.println("==================================================");
		for (Stavka s : stavke) {
			System.out.println(s.getProizvod() + " "+ s.getProizvod().getCijena() + " x " + s.getKolicina() + " = "
					+ s.getProizvod().getCijena() * s.getKolicina());
			System.out.println("_____________________________________________");

		}
	}

	public void kupovina() {
		this.datumKupovine = new Date();
		this.cijena = 0.0;
		System.out.println("Racun za kupovinu " + datumKupovine);
		System.out.println("==================================================");

		for (Stavka s : stavke) {
			cijena += s.getProizvod().getCijena() * s.getKolicina();
			System.out.println(s.getProizvod() + " "+ s.getProizvod().getCijena() + " x " + s.getKolicina() + " = "
					+ s.getProizvod().getCijena() * s.getKolicina());
		}
		System.out.println("_____________________________________________");
		System.out.println("Ukupno za placanje " + cijena);
	}

}
