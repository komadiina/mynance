package javatechnoshop.racun;

import javatechnoshop.proizvodi.Proizvod;

public class Stavka {
	
	private Integer redniBroj;
	private Proizvod proizvod;
	private Integer kolicina;
	
	
	public Stavka(Integer redniBroj, Proizvod proizvod, Integer kolicina) {
		super();
		this.redniBroj = redniBroj;
		this.proizvod = proizvod;
		this.kolicina = kolicina;
	}


	public Proizvod getProizvod() {
		return proizvod;
	}


	public void setProizvod(Proizvod proizvod) {
		this.proizvod = proizvod;
	}


	public Integer getKolicina() {
		return kolicina;
	}


	public void setKolicina(Integer kolicina) {
		this.kolicina = kolicina;
	}
	
	
	
    public Integer getRedniBroj() {
		return redniBroj;
	}


	public void setRedniBroj(Integer redniBroj) {
		this.redniBroj = redniBroj;
	}


	@Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Stavka other = (Stavka) obj;
        if ( this.redniBroj != other.redniBroj) {
            return false;
        }
        return true;
    }
	

}
