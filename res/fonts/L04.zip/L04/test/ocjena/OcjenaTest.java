package ocjena;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class OcjenaTest {
	
	public Ocjena ocjena = new Ocjena();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testOcjena() {
		assertNotNull(ocjena);
	}

	@Test
	public void testGetOcjena() {
		
		
		assertEquals("A", ocjena.getOcjena(25, 75));
		assertEquals("A", ocjena.getOcjena(20, 75));
		assertEquals("A", ocjena.getOcjena(20, 71));
		
		assertEquals("B", ocjena.getOcjena(25, 65));
		assertEquals("B", ocjena.getOcjena(20, 65));
		assertEquals("B", ocjena.getOcjena(20, 61));
		
		assertEquals("C", ocjena.getOcjena(20, 60));
		assertEquals("C", ocjena.getOcjena(25, 50));
		assertEquals("C", ocjena.getOcjena(20, 51));
		
		assertEquals("D", ocjena.getOcjena(20, 50));
		assertEquals("D", ocjena.getOcjena(25, 40));
		assertEquals("D", ocjena.getOcjena(20, 41));
		
		assertEquals("E", ocjena.getOcjena(20, 31));
		assertEquals("E", ocjena.getOcjena(25, 30));
		assertEquals("E", ocjena.getOcjena(20, 40));
		
		assertEquals("F", ocjena.getOcjena(15, 35));
		assertEquals("F", ocjena.getOcjena(15, 20));
	}
}