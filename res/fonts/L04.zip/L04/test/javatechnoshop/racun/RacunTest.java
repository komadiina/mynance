package javatechnoshop.racun;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


import javatechnoshop.exception.InvalidInputParamsException;
import javatechnoshop.exception.NegativeValueException;
import javatechnoshop.matcher.EmptyOptionalMatcher;
import javatechnoshop.proizvodi.Proizvodjac;
import javatechnoshop.proizvodi.Racunar;



import static org.hamcrest.Matchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;;



class RacunTest {
	
	private Racun racun;
	
	private Proizvodjac lenovo; 
	private Racunar r1, r2;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		racun = new Racun();
		
		Proizvodjac lenovo = new Proizvodjac("Lenovo", "Kina", "info@lenovo.com");

	    r1 = new Racunar("Intel i3, RAM 4 GB, HDD 300 GB, Windows 7", "r100", 1025.5, "Laptop ThinkPad", lenovo);
	    r2 = new Racunar("Intel i5, RAM 8 GB, HDD 500 GB, Windows 7", "r101", 1325.5, "Laptop ThinkPad", lenovo);    

	}

	@AfterEach
	void tearDown() throws Exception {
	}
	
	@Test
	@DisplayName("Sve na jednom mjestu")
	void testAzurirajStavku() throws NegativeValueException, InvalidInputParamsException  {
       
                
        racun.azurirajStavku(r1, 30);
		assertThat(30, is(racun.getStavkaSaSifromProizvoda(r1.getSifra()).get().getKolicina()));
		
		racun.azurirajStavku(r1, 30);
		assertThat(60, is(racun.getStavkaSaSifromProizvoda(r1.getSifra()).get().getKolicina()));
		
		racun.azurirajStavku(r1, -60);
		assertThat(racun.getStavkaSaSifromProizvoda(r1.getSifra()), is(emptyOptional()));
		
		
		racun.azurirajStavku(r2, 30);
		
        Exception exception1 = assertThrows(
        		NegativeValueException.class, 
	            () -> racun.azurirajStavku(r2, -40));
        assertThat(exception1, is(instanceOf(NegativeValueException.class)));
        
        Exception exception2 = assertThrows(
        		InvalidInputParamsException.class, 
	            () -> racun.azurirajStavku(null, -40));
        assertThat(exception2, is(instanceOf(InvalidInputParamsException.class)));
        
        Exception exception3 = assertThrows(
        		InvalidInputParamsException.class, 
	            () -> racun.azurirajStavku(null, -40));
        assertThat(exception3, is(instanceOf(InvalidInputParamsException.class)));
        
        Exception exception4 = assertThrows(
        		InvalidInputParamsException.class, 
	            () -> racun.azurirajStavku(null, null));
        assertThat(exception4, is(instanceOf(InvalidInputParamsException.class)));
        
        Exception exception5 = assertThrows(
        		InvalidInputParamsException.class, 
	            () -> racun.azurirajStavku(r1, null));
        assertThat(exception5, is(instanceOf(InvalidInputParamsException.class)));
		
	}
	
	
	@Test
	@DisplayName("Testiranje dodavanja pozitivne kolicine na stavku")
	void testAzurirajStavkuPozitivnaKolicina()  throws NegativeValueException, InvalidInputParamsException {
                
        racun.azurirajStavku(r1, 30);
		assertThat(30, is(racun.getStavkaSaSifromProizvoda(r1.getSifra()).get().getKolicina()));
		
		racun.azurirajStavku(r1, 30);
		assertThat(60, is(racun.getStavkaSaSifromProizvoda(r1.getSifra()).get().getKolicina()));
		
	}
	
	
	@Test
	@DisplayName("Testiranje brisanja stavke zbog kolicine")
	void testAzurirajStavkuBrisanje() throws NegativeValueException, InvalidInputParamsException  {
		
		racun.azurirajStavku(r1, 30);
		racun.azurirajStavku(r1, 30);
		
		racun.azurirajStavku(r1, -60);
		assertThat(racun.getStavkaSaSifromProizvoda(r1.getSifra()), is(emptyOptional()));
		
	}
	
	@Test
	@DisplayName("Testiranje negativne vrijednosti")
	void testAzurirajStavkuNegativnaVrijednost() throws NegativeValueException, InvalidInputParamsException  {
		
		racun.azurirajStavku(r2, 30);
		
        Exception exception1 = assertThrows(
        		NegativeValueException.class, 
	            () -> racun.azurirajStavku(r2, -40));
        assertThat(exception1, is(instanceOf(NegativeValueException.class)));
		
	}
	
	@Test
	@DisplayName("Testiranje da li su validni parametri")
	void testAzurirajStavkuValidniParametri() throws NegativeValueException, InvalidInputParamsException  {
		
		racun.azurirajStavku(r2, 30);
		
        Exception exception2 = assertThrows(
        		InvalidInputParamsException.class, 
	            () -> racun.azurirajStavku(null, 30));
        assertThat(exception2, is(instanceOf(InvalidInputParamsException.class)));
        
        Exception exception3 = assertThrows(
        		InvalidInputParamsException.class, 
	            () -> racun.azurirajStavku(null, 30));
        assertThat(exception3, is(instanceOf(InvalidInputParamsException.class)));
        
        Exception exception4 = assertThrows(
        		InvalidInputParamsException.class, 
	            () -> racun.azurirajStavku(null, null));
        assertThat(exception4, is(instanceOf(InvalidInputParamsException.class)));
        
        Exception exception5 = assertThrows(
        		InvalidInputParamsException.class, 
	            () -> racun.azurirajStavku(r1, null));
        assertThat(exception5, is(instanceOf(InvalidInputParamsException.class)));
		
	}
	
	
    public static <T> Matcher<? super Optional<T>> emptyOptional() {
        return new EmptyOptionalMatcher<>();
    }
	
	

}
