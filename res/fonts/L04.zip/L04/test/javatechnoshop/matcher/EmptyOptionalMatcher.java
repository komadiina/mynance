package javatechnoshop.matcher;

import java.util.Optional;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

public class EmptyOptionalMatcher<T> extends BaseMatcher<Optional<T>> {

    private Optional<T> optionalActual;

    public EmptyOptionalMatcher() {
    }

    @Override
    public boolean matches(Object item) {
        optionalActual = (Optional<T>) item;

        if (optionalActual == null) {
            return false;
        }

        boolean empty = !optionalActual.isPresent();
        return empty;
    }

    @Override
    public void describeTo(Description description) {
        description.appendText("optional is empty");
    }

    @Override
    public void describeMismatch(Object item, Description description) {
        if (optionalActual == null) {
            description.appendText(" optional was NULL?");
        } else {
            description.appendText(" was: " + optionalActual.get());
        }
    }
    


}